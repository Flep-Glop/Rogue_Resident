DEBUG = True
TESTING = True
SECRET_KEY = 'test-secret-key'
DATABASE_PATH = ':memory:'
