/**
 * StateManager implementation
 */
const StateManager = {
    init() {
        console.log('StateManager initialized');
    }
};

export { StateManager };
