/**
 * Game implementation
 */
const Game = {
    init() {
        console.log('Game initialized');
    }
};

export { Game };
