DEBUG = True
SECRET_KEY = 'dev-secret-key'
DATABASE_PATH = 'game_data.db'
