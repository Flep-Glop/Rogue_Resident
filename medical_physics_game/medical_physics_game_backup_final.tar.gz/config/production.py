DEBUG = False
SECRET_KEY = 'production-secret-key-change-me'
DATABASE_PATH = '/var/www/medical_physics_game/game_data.db'
