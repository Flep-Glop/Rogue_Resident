"""
skill tree routes API routes for the Medical Physics Game.
"""

from flask import jsonify, request
from . import api_bp

# Add route implementations here
