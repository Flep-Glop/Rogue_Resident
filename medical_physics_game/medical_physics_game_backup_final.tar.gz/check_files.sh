#!/bin/bash

echo "Content of frontend/src/core/bootstrap.js:"
echo "----------------------------------------"
cat frontend/src/core/bootstrap.js
echo ""
echo "Content of frontend/src/core/game.js:"
echo "----------------------------------------"
cat frontend/src/core/game.js
